Before running `index.jsp` on tomcat server, please change the database username and password in Util.Constant. This website relies on local database.
You can still experience functionality of networking and multi-threaded by using different account at local.

If the website seems malformatted, you can try to refresh the page with `Shift` + refresh, which may solve the problem that the browser does not load the css files.
